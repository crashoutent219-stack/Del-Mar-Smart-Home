WASABI ESTATES - DEL MAR SMART HOME
HTML WALL SCREEN PROTOTYPE - OCTOBER 2026

FILES
- delmar.html: responsive HTML/CSS/JavaScript interface with 18 configurable zones.
- DELMAR_MOAP_LOADER.lsl: optional script that displays the hosted page on one Second Life prim face.

WHAT WORKS IN THE HTML PREVIEW
- Interactive pages: Home, Lights, Fans, Pool, Security, Doorbell, Settings.
- 18 lighting zones: 6 bedrooms, 5 bathrooms, garage, kitchen, dining, living,
  2 hallways and exterior.
- Rename any room while preserving stable internal group IDs.
- Mock group light ON/OFF, brightness, and color controls.
- Mock ceiling fan OFF/LOW/MEDIUM/HIGH; mock pool motor controls.
- Mock security toggles and kick time; mock doorbell alert display.
- Cleaning requirement ON/OFF placeholder; no cleaning mechanics yet.
- Browser-local demo save, settings JSON export/import.

WHAT IS NOT IMPLEMENTED
- Actual Second Life light/fan/pool/security/doorbell control.
- In-world fixture pairing or secure authorized control.
- In-world persistence, cross-viewer sync, notification streaming.
- The cleaning gameplay, dirt percentages, roaches or mice.

INSTALLATION TEST
1. Open delmar.html in Chrome to inspect the UI.
2. To display it in Second Life, host delmar.html at an HTTPS URL.
3. Rez a wall panel prim. Install DELMAR_MOAP_LOADER.lsl.
4. Change SCREEN_URL to the hosted HTTPS URL and SCREEN_FACE to the display face.
5. Ensure Shared Media is enabled in your Second Life viewer.
6. The HTML interface will render. It is only a demonstration until an
   authenticated bridge is connected to your house master LSL controller.

DESIGN NOTES
- One media face, avoiding numerous prim buttons.
- No external font or framework requests from the HTML.
- Only one localStorage object in the demo. Future authoritative data should
  be stored by the in-world house master using Linkset Data.
- Second Life HTML media is per viewer; browser storage is not household data.
- Access controls shown in HTML are NOT security enforcement. Permissions
  must be verified on the server and/or LSL device side.
- To make a reliable sellable product, hosting and a secure relay/bridge must
  be designed and tested before the buttons can operate real devices.
