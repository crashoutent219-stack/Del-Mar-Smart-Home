// ========================================================
// WASABI ESTATES - DEL MAR MANSION
// ONE-PRIM WALL SCREEN - MOAP PAGE LOADER (UI ONLY)
// ========================================================
// STEP 1: Host delmar.html at an HTTPS web address.
// STEP 2: Put that URL below. Do not use a local file path.
// STEP 3: Place this script in the wall-screen prim.
// STEP 4: Set SCREEN_FACE to the visible display face.
// STEP 5: Save/reset the script. Enable Shared Media in viewer.
//
// This loader displays the webpage. It DOES NOT yet connect
// buttons to your mansion devices or store house settings.
// A secure HTML-to-LSL bridge is required for that.
// ========================================================

integer SCREEN_FACE = 4; // Change if your prim's screen uses a different face
string SCREEN_URL = "https://YOUR-HTTPS-HOST.example/delmar.html";

LoadDisplay()
{
    if (llSubStringIndex(SCREEN_URL, "https://YOUR-") == 0 ||
        llSubStringIndex(SCREEN_URL, "https://") != 0)
    {
        llOwnerSay("Del Mar: Set SCREEN_URL to your hosted HTTPS delmar.html address.");
        return;
    }

    integer result = llSetPrimMediaParams(SCREEN_FACE, [
        PRIM_MEDIA_HOME_URL, SCREEN_URL,
        PRIM_MEDIA_CURRENT_URL, SCREEN_URL,
        PRIM_MEDIA_AUTO_PLAY, TRUE,
        PRIM_MEDIA_AUTO_SCALE, TRUE,
        PRIM_MEDIA_AUTO_ZOOM, FALSE,
        PRIM_MEDIA_FIRST_CLICK_INTERACT, TRUE,
        PRIM_MEDIA_WIDTH_PIXELS, 1024,
        PRIM_MEDIA_HEIGHT_PIXELS, 768,
        PRIM_MEDIA_CONTROLS, PRIM_MEDIA_CONTROLS_MINI,
        PRIM_MEDIA_PERMS_INTERACT, PRIM_MEDIA_PERM_ANYONE,
        PRIM_MEDIA_PERMS_CONTROL, PRIM_MEDIA_PERM_OWNER
    ]);

    if (result != STATUS_OK)
    {
        llOwnerSay("Del Mar: Media setup status: " + (string)result + ". Check face and permissions.");
    }
}

default
{
    state_entry()
    {
        LoadDisplay();
    }
    on_rez(integer start_param)
    {
        llResetScript();
    }
    changed(integer change)
    {
        if (change & CHANGED_OWNER)
        {
            llResetScript();
        }
    }
}
